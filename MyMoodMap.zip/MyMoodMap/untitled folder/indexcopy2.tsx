import React, { useEffect, useState } from 'react';
import {
    Alert,
    Dimensions,
    ScrollView,
    StyleSheet,
    Switch,
    Text,
    TextInput,
    TouchableOpacity,
    View,
} from 'react-native';
import { LineChart } from 'react-native-chart-kit';

// Types
type Mood = '😊' | '😐' | '😢' | '😠' | '😴' | string;
type MoodEntry = {
  id: string;
  mood: Mood;
  note: string;
  timestamp: Date;
  date: string;
  moodValue: number;
};

type AppScreen =
  | 'onboarding-1'
  | 'onboarding-2'
  | 'onboarding-3'
  | 'login'
  | 'welcome'
  | 'mood-entry'
  | 'history'
  | 'edit-mood'
  | 'calendar'
  | 'analytics'
  | 'settings'
  | 'customization';

// Simple in-memory storage for demo / tests
let tempStorage: any = {
  user: null,
  moodHistory: [],
  onboardingCompleted: false,
  customMoods: null,
  notifications: { enabled: false, time: '20:00' },
};

const tempAsyncStorage = {
  setItem: async (key: string, value: string) => {
    tempStorage[key] = value;
    return Promise.resolve();
  },
  getItem: async (key: string) => {
    const val = tempStorage[key];
    return Promise.resolve(val == null ? 'null' : JSON.stringify(val));
  },
  removeItem: async (key: string) => {
    delete tempStorage[key];
    return Promise.resolve();
  },
};

export default function HomeScreen() {
  const [currentScreen, setCurrentScreen] = useState<AppScreen>('onboarding-1');
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [selectedMood, setSelectedMood] = useState<Mood | null>(null);
  const [note, setNote] = useState('');
  const [moodHistory, setMoodHistory] = useState<MoodEntry[]>([]);
  const [editingEntry, setEditingEntry] = useState<MoodEntry | null>(null);
  const [selectedDate, setSelectedDate] = useState<string>('');

  // Notifications & Onboarding
  const [notificationsEnabled, setNotificationsEnabled] = useState(false);
  const [reminderTime, setReminderTime] = useState('20:00');
  const [onboardingCompleted, setOnboardingCompleted] = useState(false);

  // Customization
  const [customMoods, setCustomMoods] = useState<Mood[]>(['😊', '😐', '😢', '😠', '😴']);
  const [newMoodEmoji, setNewMoodEmoji] = useState('');
  const [isAddingMood, setIsAddingMood] = useState(false);

  useEffect(() => {
    initializeApp();
  }, []);

  const initializeApp = async () => {
    await checkOnboardingStatus();
    await checkLoginStatus();
    await loadMoodHistory();
    await loadSettings();
  };

  const checkOnboardingStatus = async () => {
    const completed = await tempAsyncStorage.getItem('onboardingCompleted');
    if (completed && completed !== 'null') {
      setOnboardingCompleted(true);
      setCurrentScreen('login');
    } else {
      setCurrentScreen('onboarding-1');
    }
  };

  const checkLoginStatus = async () => {
    const userData = await tempAsyncStorage.getItem('user');
    if (userData && userData !== 'null') {
      setIsLoggedIn(true);
      setCurrentScreen('welcome');
    }
  };

  const loadMoodHistory = async () => {
    const history = await tempAsyncStorage.getItem('moodHistory');
    if (history && history !== 'null') {
      const parsedHistory = JSON.parse(history).map((entry: any) => ({
        ...entry,
        timestamp: new Date(entry.timestamp),
      }));
      setMoodHistory(parsedHistory);
    }
  };

  const loadSettings = async () => {
    const notifications = await tempAsyncStorage.getItem('notifications');
    const moods = await tempAsyncStorage.getItem('customMoods');

    if (notifications && notifications !== 'null') {
      const notificationSettings = JSON.parse(notifications);
      setNotificationsEnabled(!!notificationSettings.enabled);
      setReminderTime(notificationSettings.time || '20:00');
    }

    if (moods && moods !== 'null') {
      try {
        setCustomMoods(JSON.parse(moods));
      } catch (e) {
        // ignore parse errors
      }
    }
  };

  const handleLogin = async () => {
    if (email && password) {
      try {
        await tempAsyncStorage.setItem('user', JSON.stringify({ email }));
        setIsLoggedIn(true);
        setCurrentScreen('welcome');
        Alert.alert('Success', 'Logged in successfully!');
      } catch (error) {
        Alert.alert('Error', 'Failed to login');
      }
    } else {
      Alert.alert('Error', 'Please enter email and password');
    }
  };

  const handleLogout = async () => {
    try {
      await tempAsyncStorage.removeItem('user');
      setIsLoggedIn(false);
      setCurrentScreen('login');
      setEmail('');
      setPassword('');
    } catch (error) {
      console.log('Error logging out:', error);
    }
  };

  const getMoodValue = (mood: Mood): number => {
    const values: Record<string, number> = { '😊': 4, '😐': 3, '😢': 2, '😠': 1, '😴': 0 };
    return values[mood] ?? 2;
  };

  const saveMood = async () => {
    if (selectedMood) {
      const today = new Date().toISOString().split('T')[0];

      const newEntry: MoodEntry = {
        id: Date.now().toString(),
        mood: selectedMood,
        note: note,
        timestamp: new Date(),
        date: today,
        moodValue: getMoodValue(selectedMood),
      };

      const updatedHistory = [newEntry, ...moodHistory];
      setMoodHistory(updatedHistory);
      await tempAsyncStorage.setItem('moodHistory', JSON.stringify(updatedHistory));

      Alert.alert('Mood Saved!', `You're feeling: ${selectedMood}`);
      setSelectedMood(null);
      setNote('');
      setCurrentScreen('welcome');
    } else {
      Alert.alert('Select a mood', 'Please choose how you feel first');
    }
  };

  const startEditMood = (entry: MoodEntry) => {
    setEditingEntry(entry);
    setSelectedMood(entry.mood);
    setNote(entry.note);
    setCurrentScreen('edit-mood');
  };

  const updateMood = async () => {
    if (editingEntry && selectedMood) {
      const updatedHistory = moodHistory.map((entry) =>
        entry.id === editingEntry.id
          ? { ...entry, mood: selectedMood, note: note, moodValue: getMoodValue(selectedMood) }
          : entry
      );

      setMoodHistory(updatedHistory);
      await tempAsyncStorage.setItem('moodHistory', JSON.stringify(updatedHistory));
      Alert.alert('Success', 'Mood entry updated!');

      setEditingEntry(null);
      setSelectedMood(null);
      setNote('');
      setCurrentScreen('history');
    }
  };

  const deleteMood = (entry: MoodEntry) => {
    Alert.alert('Delete Mood Entry', 'Are you sure you want to delete this mood entry?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete',
        style: 'destructive',
        onPress: async () => {
          const updatedHistory = moodHistory.filter((e) => e.id !== entry.id);
          setMoodHistory(updatedHistory);
          await tempAsyncStorage.setItem('moodHistory', JSON.stringify(updatedHistory));
          Alert.alert('Success', 'Mood entry deleted!');
        },
      },
    ]);
  };

  const getMoodForDate = (date: string): Mood | null => {
    const entry = moodHistory.find((entry) => entry.date === date);
    return entry ? entry.mood : null;
  };

  const getDateEntries = (date: string): MoodEntry[] => {
    return moodHistory.filter((entry) => entry.date === date);
  };

  const getMoodStats = () => {
    if (moodHistory.length === 0) return null;

    const moodCounts = moodHistory.reduce((acc: Record<string, number>, entry) => {
      acc[entry.mood] = (acc[entry.mood] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    const mostFrequentMood = Object.entries(moodCounts).sort((a, b) => b[1] - a[1])[0][0];

    return {
      totalEntries: moodHistory.length,
      mostFrequentMood,
      averageMood: moodHistory.reduce((sum, entry) => sum + entry.moodValue, 0) / moodHistory.length,
    };
  };

  const getChartData = () => {
    const last7Entries = moodHistory.slice(0, 7).reverse();

    return {
      labels: last7Entries.map((entry) =>
        new Date(entry.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
      ),
      datasets: [
        {
          data: last7Entries.map((entry) => entry.moodValue),
        },
      ],
    };
  };

  const toggleNotifications = async (value: boolean) => {
    setNotificationsEnabled(value);
    const settings = { enabled: value, time: reminderTime };
    await tempAsyncStorage.setItem('notifications', JSON.stringify(settings));

    if (value) {
      Alert.alert('Reminders Enabled', `Daily reminders set for ${reminderTime}`);
    } else {
      Alert.alert('Reminders Disabled', 'Daily reminders turned off');
    }
  };

  const completeOnboarding = async () => {
    setOnboardingCompleted(true);
    await tempAsyncStorage.setItem('onboardingCompleted', 'true');
    setCurrentScreen('login');
  };

  const addCustomMood = async () => {
    if (newMoodEmoji && !customMoods.includes(newMoodEmoji)) {
      const updatedMoods = [...customMoods, newMoodEmoji];
      setCustomMoods(updatedMoods);
      await tempAsyncStorage.setItem('customMoods', JSON.stringify(updatedMoods));
      setNewMoodEmoji('');
      setIsAddingMood(false);
      Alert.alert('Success', 'New mood added!');
    }
  };

  const removeCustomMood = async (mood: Mood) => {
    if (customMoods.length <= 3) {
      Alert.alert('Cannot Remove', 'You need at least 3 mood categories');
      return;
    }

    const updatedMoods = customMoods.filter((m) => m !== mood);
    setCustomMoods(updatedMoods);
    await tempAsyncStorage.setItem('customMoods', JSON.stringify(updatedMoods));
    Alert.alert('Removed', 'Mood category removed');
  };

  // Screens (kept inline for brevity)
  const OnboardingScreen1 = () => (
    <View style={styles.onboardingContainer}>
      <Text style={styles.onboardingTitle}>Welcome to My Mood Map!</Text>
      <Text style={styles.onboardingDescription}>
        Track your daily emotions and understand your mood patterns over time.
      </Text>
      <View style={styles.onboardingImagePlaceholder}>
        <Text style={styles.emojiLarge}>📱</Text>
      </View>
      <TouchableOpacity style={styles.onboardingButton} onPress={() => setCurrentScreen('onboarding-2')}>
        <Text style={styles.onboardingButtonText}>Next</Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.skipButton} onPress={completeOnboarding}>
        <Text style={styles.skipButtonText}>Skip Tutorial</Text>
      </TouchableOpacity>
    </View>
  );

  const OnboardingScreen2 = () => (
    <View style={styles.onboardingContainer}>
      <Text style={styles.onboardingTitle}>Log Your Mood Daily ✨</Text>
      <Text style={styles.onboardingDescription}>
        Simply tap an emoji to log how you're feeling. Add optional notes for context.
      </Text>
      <View style={styles.onboardingImagePlaceholder}>
        <Text style={styles.emojiLarge}>😊 😐 😢 😠 😴</Text>
        <Text style={styles.onboardingSubtext}>Choose from mood options</Text>
      </View>
      <TouchableOpacity style={styles.onboardingButton} onPress={() => setCurrentScreen('onboarding-3')}>
        <Text style={styles.onboardingButtonText}>Next</Text>
      </TouchableOpacity>
    </View>
  );

  const OnboardingScreen3 = () => (
    <View style={styles.onboardingContainer}>
      <Text style={styles.onboardingTitle}>Track & Analyze 📊</Text>
      <Text style={styles.onboardingDescription}>
        View your mood history on a calendar and see trends with beautiful charts.
      </Text>
      <View style={styles.onboardingImagePlaceholder}>
        <Text style={styles.emojiLarge}>📅 📈</Text>
        <Text style={styles.onboardingSubtext}>Calendar and analytics views</Text>
      </View>
      <TouchableOpacity style={styles.onboardingButton} onPress={completeOnboarding}>
        <Text style={styles.onboardingButtonText}>Get Started</Text>
      </TouchableOpacity>
    </View>
  );

  const LoginScreen = () => (
    <View style={styles.container}>
      <Text style={styles.title}>My Mood Map</Text>
      <Text style={styles.subtitle}>Welcome! Please login</Text>

      <View style={styles.inputContainer}>
        <TextInput
          style={styles.input}
          placeholder="Email"
          value={email}
          onChangeText={setEmail}
          keyboardType="email-address"
          autoCapitalize="none"
        />
        <TextInput
          style={styles.input}
          placeholder="Password"
          value={password}
          onChangeText={setPassword}
          secureTextEntry
        />
      </View>

      <TouchableOpacity style={styles.primaryButton} onPress={handleLogin}>
        <Text style={styles.buttonText}>Login</Text>
      </TouchableOpacity>

      <Text style={styles.demoText}>Use any email and password</Text>
    </View>
  );

  const WelcomeScreen = () => {
    const stats = getMoodStats();

    return (
      <View style={styles.container}>
        <Text style={styles.title}>My Mood Map</Text>
        <Text style={styles.subtitle}>Welcome back! 👋</Text>

        {stats && (
          <View style={styles.statsContainer}>
            <Text style={styles.statsTitle}>Your Mood Insights</Text>
            <Text style={styles.statsText}>Total Entries: {stats.totalEntries}</Text>
            <Text style={styles.statsText}>Most Common Mood: {stats.mostFrequentMood}</Text>
          </View>
        )}

        <TouchableOpacity style={styles.primaryButton} onPress={() => setCurrentScreen('mood-entry')}>
          <Text style={styles.buttonText}>Log New Mood</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.secondaryButton} onPress={() => setCurrentScreen('history')}>
          <Text style={styles.buttonText}>View History</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.tertiaryButton} onPress={() => setCurrentScreen('calendar')}>
          <Text style={styles.buttonText}>Calendar View</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.tertiaryButton} onPress={() => setCurrentScreen('analytics')}>
          <Text style={styles.buttonText}>Mood Analytics</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.settingsButton} onPress={() => setCurrentScreen('settings')}>
          <Text style={styles.buttonText}>Settings</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.logoutButton} onPress={handleLogout}>
          <Text style={styles.buttonText}>Logout</Text>
        </TouchableOpacity>
      </View>
    );
  };

  const MoodEntryScreen = () => (
    <ScrollView style={styles.container} contentContainerStyle={styles.scrollContent}>
      <Text style={styles.title}>How are you feeling?</Text>

      <View style={styles.moodContainer}>
        {customMoods.map((mood, index) => (
          <TouchableOpacity
            key={index}
            style={[styles.moodOption, selectedMood === mood && styles.selectedMood]}
            onPress={() => setSelectedMood(mood)}
          >
            <Text style={styles.moodEmoji}>{mood}</Text>
          </TouchableOpacity>
        ))}
      </View>

      {selectedMood && (
        <View style={styles.noteContainer}>
          <Text style={styles.noteLabel}>Add a note (optional, max 200 chars):</Text>
          <TextInput
            style={styles.textInput}
            placeholder="What's making you feel this way?"
            value={note}
            onChangeText={setNote}
            multiline
            maxLength={200}
            textAlignVertical="top"
          />
          <Text style={styles.charCount}>{note.length}/200 characters</Text>
        </View>
      )}

      <View style={styles.actionContainer}>
        <TouchableOpacity
          style={[styles.saveButton, !selectedMood && styles.saveButtonDisabled]}
          onPress={saveMood}
          disabled={!selectedMood}
        >
          <Text style={styles.saveButtonText}>{selectedMood ? 'Save Mood' : 'Select a Mood First'}</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.backButton} onPress={() => setCurrentScreen('welcome')}>
          <Text style={styles.backButtonText}>Back to Home</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );

  const HistoryScreen = () => (
    <View style={styles.container}>
      <Text style={styles.title}>Mood History</Text>

      <ScrollView style={styles.historyContainer}>
        {moodHistory.length === 0 ? (
          <Text style={styles.noHistory}>No mood entries yet</Text>
        ) : (
          moodHistory.map((entry) => (
            <View key={entry.id} style={styles.historyItem}>
              <Text style={styles.historyEmoji}>{entry.mood}</Text>
              <View style={styles.historyDetails}>
                <Text style={styles.historyDate}>
                  {entry.timestamp.toLocaleDateString()} at {entry.timestamp.toLocaleTimeString()}
                </Text>
                {entry.note ? <Text style={styles.historyNote}>"{entry.note}"</Text> : null}
              </View>
              <View style={styles.historyActions}>
                <TouchableOpacity style={styles.editButton} onPress={() => startEditMood(entry)}>
                  <Text style={styles.editButtonText}>Edit</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.deleteButton} onPress={() => deleteMood(entry)}>
                  <Text style={styles.deleteButtonText}>Delete</Text>
                </TouchableOpacity>
              </View>
            </View>
          ))
        )}
      </ScrollView>

      <TouchableOpacity style={styles.backButton} onPress={() => setCurrentScreen('welcome')}>
        <Text style={styles.backButtonText}>Back to Home</Text>
      </TouchableOpacity>
    </View>
  );

  const EditMoodScreen = () => (
    <ScrollView style={styles.container} contentContainerStyle={styles.scrollContent}>
      <Text style={styles.title}>Edit Mood Entry</Text>

      <View style={styles.moodContainer}>
        {customMoods.map((mood, index) => (
          <TouchableOpacity
            key={index}
            style={[styles.moodOption, selectedMood === mood && styles.selectedMood]}
            onPress={() => setSelectedMood(mood)}
          >
            <Text style={styles.moodEmoji}>{mood}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <View style={styles.noteContainer}>
        <Text style={styles.noteLabel}>Edit note:</Text>
        <TextInput
          style={styles.textInput}
          value={note}
          onChangeText={setNote}
          multiline
          maxLength={200}
          textAlignVertical="top"
        />
        <Text style={styles.charCount}>{note.length}/200 characters</Text>
      </View>

      <View style={styles.actionContainer}>
        <TouchableOpacity style={styles.saveButton} onPress={updateMood}>
          <Text style={styles.saveButtonText}>Save Changes</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.cancelEditButton}
          onPress={() => {
            setEditingEntry(null);
            setSelectedMood(null);
            setNote('');
            setCurrentScreen('history');
          }}
        >
          <Text style={styles.cancelEditButtonText}>Cancel</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );

  const CalendarScreen = () => {
    const today = new Date();
    const currentMonth = today.getMonth();
    const currentYear = today.getFullYear();

    const getDaysInMonth = (year: number, month: number) => {
      return new Date(year, month + 1, 0).getDate();
    };

    const getFirstDayOfMonth = (year: number, month: number) => {
      return new Date(year, month, 1).getDay();
    };

    const generateCalendar = () => {
      const daysInMonth = getDaysInMonth(currentYear, currentMonth);
      const firstDay = getFirstDayOfMonth(currentYear, currentMonth);
      const calendar: (string | null)[] = [];

      for (let i = 0; i < firstDay; i++) calendar.push(null);

      for (let day = 1; day <= daysInMonth; day++) {
        const dateStr = `${currentYear}-${String(currentMonth + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
        calendar.push(dateStr);
      }

      return calendar;
    };

    const calendarDays = generateCalendar();

    return (
      <View style={styles.container}>
        <Text style={styles.title}>Mood Calendar</Text>
        <Text style={styles.subtitle}>{today.toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}</Text>

        <View style={styles.calendarGrid}>
          {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day) => (
            <Text key={day} style={styles.calendarHeader}>
              {day}
            </Text>
          ))}

          {calendarDays.map((date, index) => (
            <TouchableOpacity
              key={index}
              style={[styles.calendarCell, !date && styles.calendarEmptyCell]}
              onPress={() => date && setSelectedDate(date)}
              disabled={!date}
            >
              {date && (
                <>
                  <Text style={styles.calendarDate}>{new Date(date).getDate()}</Text>
                  {getMoodForDate(date) && <Text style={styles.calendarMood}>{getMoodForDate(date)}</Text>}
                </>
              )}
            </TouchableOpacity>
          ))}
        </View>

        {selectedDate && (
          <View style={styles.dateDetails}>
            <Text style={styles.detailsTitle}>Moods for {new Date(selectedDate).toLocaleDateString()}</Text>
            {getDateEntries(selectedDate).map((entry) => (
              <View key={entry.id} style={styles.detailEntry}>
                <Text style={styles.detailEmoji}>{entry.mood}</Text>
                <Text style={styles.detailTime}>
                  {entry.timestamp.toLocaleTimeString()}
                  {entry.note && ` - "${entry.note}"`}
                </Text>
              </View>
            ))}
            {getDateEntries(selectedDate).length === 0 && <Text style={styles.noEntries}>No mood entries for this date</Text>}
          </View>
        )}

        <TouchableOpacity style={styles.backButton} onPress={() => setCurrentScreen('welcome')}>
          <Text style={styles.backButtonText}>Back to Home</Text>
        </TouchableOpacity>
      </View>
    );
  };

  const AnalyticsScreen = () => {
    const stats = getMoodStats();
    const chartData = getChartData();
    const hasEnoughData = moodHistory.length >= 7;

    return (
      <ScrollView style={styles.container}>
        <Text style={styles.title}>Mood Analytics</Text>

        {stats && (
          <View style={styles.statsContainer}>
            <Text style={styles.statsTitle}>Your Mood Overview</Text>
            <Text style={styles.statsText}>Total Entries: {stats.totalEntries}</Text>
            <Text style={styles.statsText}>Most Common: {stats.mostFrequentMood}</Text>
            <Text style={styles.statsText}>Average Mood Level: {stats.averageMood.toFixed(1)}/4</Text>
          </View>
        )}
        

        {hasEnoughData ? (
          <View style={styles.chartContainer}>
            <Text style={styles.chartTitle}>Mood Trends (Last 7 Entries)</Text>
            <LineChart
              data={chartData}
              width={Dimensions.get('window').width - 40}
              height={220}
              chartConfig={{
                backgroundColor: '#ffffff',
                backgroundGradientFrom: '#ffffff',
                backgroundGradientTo: '#ffffff',
                decimalPlaces: 0,
                color: (opacity = 1) => `rgba(52, 152, 219, ${opacity})`,
                labelColor: (opacity = 1) => `rgba(0, 0, 0, ${opacity})`,
                style: { borderRadius: 16 },
                propsForDots: { r: '4', strokeWidth: '2', stroke: '#3498db' },
              }}
              bezier
              style={styles.chart}
            />
            <Text style={styles.chartLegend}>Mood Scale: 😴(0) - 😢(1) - 😠(2) - 😐(3) - 😊(4)</Text>
          </View>
        ) : (
          <View style={styles.insufficientData}>
            <Text style={styles.insufficientDataText}>Need at least 7 mood entries to show trends</Text>
            <Text style={styles.insufficientDataSubtext}>You have {moodHistory.length} of 7 required entries</Text>
          </View>
        )}

        <TouchableOpacity style={styles.backButton} onPress={() => setCurrentScreen('welcome')}>
          <Text style={styles.backButtonText}>Back to Home</Text>
        </TouchableOpacity>
      </ScrollView>
    );
  };

  const SettingsScreen = () => (
    <View style={styles.container}>
      <Text style={styles.title}>Settings</Text>

      <View style={styles.settingsContainer}>
        <View style={styles.settingItem}>
          <View style={styles.settingText}>
            <Text style={styles.settingTitle}>Daily Reminders</Text>
            <Text style={styles.settingDescription}>Receive daily notifications to log your mood</Text>
          </View>
          <Switch
            value={notificationsEnabled}
            onValueChange={toggleNotifications}
            trackColor={{ false: '#767577', true: '#81b0ff' }}
            thumbColor={notificationsEnabled ? '#3498db' : '#f4f3f4'}
          />
        </View>

        {notificationsEnabled && (
          <View style={styles.timeSetting}>
            <Text style={styles.timeLabel}>Reminder Time:</Text>
            <View style={styles.timeInputContainer}>
              <TextInput style={styles.timeInput} value={reminderTime} onChangeText={setReminderTime} placeholder="20:00" maxLength={5} />
              <Text style={styles.timeFormat}>24-hour format (HH:MM)</Text>
            </View>
          </View>
        )}

        <TouchableOpacity style={styles.customizationButton} onPress={() => setCurrentScreen('customization')}>
          <Text style={styles.customizationButtonText}>Customize Mood Categories</Text>
        </TouchableOpacity>
      </View>


      <TouchableOpacity style={styles.backButton} onPress={() => setCurrentScreen('welcome')}>
        <Text style={styles.backButtonText}>Back to Home</Text>
      </TouchableOpacity>
    </View>
  );

  const CustomizationScreen = () => (
    <View style={styles.container}>
      <Text style={styles.title}>Customize Moods</Text>
      <Text style={styles.subtitle}>Add or remove mood categories</Text>

      <ScrollView style={styles.customizationContainer}>
        {customMoods.map((mood, index) => (
          <View key={index} style={styles.moodItem}>
            <View style={styles.moodDisplay}>
              <Text style={styles.moodEmoji}>{mood}</Text>
            </View>
            {customMoods.length > 3 && (
              <TouchableOpacity style={styles.removeButton} onPress={() => removeCustomMood(mood)}>
                <Text style={styles.removeButtonText}>Remove</Text>
              </TouchableOpacity>
            )}
          </View>
        ))}
      </ScrollView>

      <TouchableOpacity style={styles.addButton} onPress={() => setIsAddingMood(true)}>
        <Text style={styles.addButtonText}>+ Add New Mood</Text>
      </TouchableOpacity>

      {isAddingMood && (
        <View style={styles.addMoodContainer}>
          <Text style={styles.addMoodLabel}>Enter a new emoji:</Text>
          <TextInput style={styles.addMoodInput} value={newMoodEmoji} onChangeText={setNewMoodEmoji} placeholder="😊" maxLength={2} />
          <View style={styles.addMoodActions}>
            <TouchableOpacity style={styles.cancelAddButton} onPress={() => setIsAddingMood(false)}>
              <Text style={styles.cancelAddButtonText}>Cancel</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.confirmAddButton} onPress={addCustomMood}>
              <Text style={styles.confirmAddButtonText}>Add</Text>
            </TouchableOpacity>
          </View>
        </View>
      )}

      <TouchableOpacity style={styles.backButton} onPress={() => setCurrentScreen('settings')}>
        <Text style={styles.backButtonText}>Back to Settings</Text>
      </TouchableOpacity>
    </View>
  );

  // Navigation
  if (currentScreen.startsWith('onboarding')) {
    switch (currentScreen) {
      case 'onboarding-1':
        return <OnboardingScreen1 />;
      case 'onboarding-2':
        return <OnboardingScreen2 />;
      case 'onboarding-3':
        return <OnboardingScreen3 />;
    }
  }

  if (!isLoggedIn) return <LoginScreen />;

  switch (currentScreen) {
    case 'welcome':
      return <WelcomeScreen />;
    case 'mood-entry':
      return <MoodEntryScreen />;
    case 'history':
      return <HistoryScreen />;
    case 'edit-mood':
      return <EditMoodScreen />;
    case 'calendar':
      return <CalendarScreen />;
    case 'analytics':
      return <AnalyticsScreen />;
    case 'settings':
      return <SettingsScreen />;
    case 'customization':
      return <CustomizationScreen />;
    default:
      return <WelcomeScreen />;
  }
}

const styles = StyleSheet.create({
  onboardingContainer: {
    flex: 1,
    backgroundColor: '#f8f9fa',
    padding: 40,
    justifyContent: 'center',
    alignItems: 'center',
  },
  onboardingTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#2c3e50',
    marginBottom: 20,
    textAlign: 'center',
  },
  onboardingDescription: {
    fontSize: 18,
    color: '#7f8c8d',
    textAlign: 'center',
    marginBottom: 40,
    lineHeight: 24,
  },
  onboardingSubtext: {
    fontSize: 14,
    color: '#95a5a6',
    textAlign: 'center',
    marginTop: 10,
  },
  onboardingImagePlaceholder: {
    backgroundColor: 'white',
    padding: 40,
    borderRadius: 20,
    marginBottom: 40,
    alignItems: 'center',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  emojiLarge: { fontSize: 48, marginBottom: 10 },
  onboardingButton: {
    backgroundColor: '#3498db',
    paddingVertical: 15,
    paddingHorizontal: 40,
    borderRadius: 30,
    marginBottom: 15,
    minWidth: 200,
    alignItems: 'center',
  },
  onboardingButtonText: { color: 'white', fontSize: 18, fontWeight: '600' },
  skipButton: { paddingVertical: 10 },
  skipButtonText: { color: '#7f8c8d', fontSize: 16 },

  container: { flex: 1, backgroundColor: '#f8f9fa', padding: 20 },
  scrollContent: { flexGrow: 1, justifyContent: 'center' },
  title: { fontSize: 32, fontWeight: 'bold', color: '#2c3e50', marginBottom: 10, textAlign: 'center' },
  subtitle: { fontSize: 18, color: '#7f8c8d', marginBottom: 30, textAlign: 'center' },
  demoText: { fontSize: 14, color: '#95a5a6', marginTop: 20, textAlign: 'center' },

  inputContainer: { width: '100%', maxWidth: 360, marginBottom: 30, alignSelf: 'center' },
  input: { backgroundColor: 'white', borderWidth: 1, borderColor: '#ddd', borderRadius: 10, padding: 15, marginBottom: 12 },

  primaryButton: { backgroundColor: '#3498db', padding: 14, borderRadius: 12, alignItems: 'center', marginVertical: 6 },
  secondaryButton: { backgroundColor: '#2ecc71', padding: 12, borderRadius: 12, alignItems: 'center', marginVertical: 6 },
  tertiaryButton: { backgroundColor: '#9b59b6', padding: 12, borderRadius: 12, alignItems: 'center', marginVertical: 6 },
  settingsButton: { backgroundColor: '#f39c12', padding: 12, borderRadius: 12, alignItems: 'center', marginVertical: 6 },
  logoutButton: { backgroundColor: '#e74c3c', padding: 12, borderRadius: 12, alignItems: 'center', marginVertical: 6 },
  buttonText: { color: 'white', fontSize: 16, fontWeight: '600' },

  statsContainer: { backgroundColor: 'white', padding: 16, borderRadius: 12, marginBottom: 20 },
  statsTitle: { fontSize: 18, fontWeight: '700', marginBottom: 8 },
  statsText: { fontSize: 14, color: '#34495e' },

  moodContainer: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'center', marginVertical: 10 },
  moodOption: { backgroundColor: 'white', padding: 12, margin: 6, borderRadius: 12 },
  selectedMood: { borderWidth: 2, borderColor: '#3498db' },
  moodEmoji: { fontSize: 28 },

  noteContainer: { marginTop: 12, backgroundColor: 'white', padding: 12, borderRadius: 10 },
  noteLabel: { fontSize: 14, color: '#7f8c8d', marginBottom: 6 },
  textInput: { minHeight: 80, padding: 10, borderWidth: 1, borderColor: '#eee', borderRadius: 8, backgroundColor: '#fff' },
  charCount: { textAlign: 'right', color: '#95a5a6', marginTop: 6 },

  actionContainer: { marginTop: 16, alignItems: 'center' },
  saveButton: { backgroundColor: '#2ecc71', padding: 12, borderRadius: 10, width: '80%', alignItems: 'center', marginBottom: 8 },
  saveButtonDisabled: { backgroundColor: '#bdc3c7' },
  saveButtonText: { color: 'white', fontSize: 16, fontWeight: '700' },
  backButton: { padding: 10, marginTop: 6, backgroundColor: '#ecf0f1', borderRadius: 8, alignItems: 'center' },
  backButtonText: { color: '#34495e', fontWeight: '600' },

  historyContainer: { marginVertical: 10 },
  noHistory: { textAlign: 'center', color: '#95a5a6', marginTop: 20 },
  historyItem: { flexDirection: 'row', alignItems: 'center', padding: 10, backgroundColor: '#fff', marginVertical: 6, borderRadius: 8 },
  historyEmoji: { fontSize: 26, marginRight: 12 },
  historyDetails: { flex: 1 },
  historyDate: { color: '#7f8c8d', fontSize: 12 },
  historyNote: { color: '#34495e', marginTop: 4 },
  historyActions: { flexDirection: 'row' },
  editButton: { marginRight: 8, padding: 8, backgroundColor: '#3498db', borderRadius: 6 },
  editButtonText: { color: 'white' },
  deleteButton: { padding: 8, backgroundColor: '#e74c3c', borderRadius: 6 },
  deleteButtonText: { color: 'white' },

  cancelEditButton: { marginTop: 8, padding: 10, backgroundColor: '#ecf0f1', borderRadius: 8, alignItems: 'center' },
  cancelEditButtonText: { color: '#34495e' },

  calendarGrid: { flexDirection: 'row', flexWrap: 'wrap', marginVertical: 12 },
  calendarHeader: { width: `${100 / 7}%`, textAlign: 'center', fontWeight: '700', marginBottom: 6 },
  calendarCell: { width: `${100 / 7}%`, minHeight: 60, alignItems: 'center', justifyContent: 'center', borderWidth: 0.5, borderColor: '#ecf0f1' },
  calendarEmptyCell: { backgroundColor: 'transparent' },
  calendarDate: { color: '#34495e' },
  calendarMood: { marginTop: 4 },

  dateDetails: { marginTop: 12, backgroundColor: '#fff', padding: 12, borderRadius: 8 },
  detailsTitle: { fontWeight: '700', marginBottom: 8 },
  detailEntry: { flexDirection: 'row', alignItems: 'center', marginBottom: 8 },
  detailEmoji: { fontSize: 20, marginRight: 8 },
  detailTime: { color: '#7f8c8d' },
  noEntries: { color: '#95a5a6' },

  chartContainer: { marginTop: 12, alignItems: 'center' },
  chartTitle: { fontSize: 16, fontWeight: '700', marginBottom: 8 },
  chart: { borderRadius: 16 },
  chartLegend: { marginTop: 8, color: '#7f8c8d' },
  insufficientData: { alignItems: 'center', marginTop: 20 },
  insufficientDataText: { color: '#7f8c8d', fontWeight: '600' },
  insufficientDataSubtext: { color: '#95a5a6', marginTop: 6 },

  settingsContainer: { marginTop: 12 },
  settingItem: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  settingText: { flex: 1, marginRight: 8 },
  settingTitle: { fontWeight: '700' },
  settingDescription: { color: '#7f8c8d' },
  timeSetting: { marginBottom: 12 },
  timeLabel: { fontWeight: '600' },
  timeInputContainer: { marginTop: 6 },
  timeInput: { backgroundColor: '#fff', padding: 10, borderRadius: 8, borderWidth: 1, borderColor: '#eee', width: 120 },
  timeFormat: { color: '#95a5a6', marginTop: 6 },

  customizationButton: { backgroundColor: '#3498db', padding: 12, borderRadius: 8, alignItems: 'center' },
  customizationButtonText: { color: 'white', fontWeight: '700' },
  customizationContainer: { marginVertical: 12 },
  moodItem: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 10, backgroundColor: '#fff', borderRadius: 8, marginVertical: 6 },
  moodDisplay: { flexDirection: 'row', alignItems: 'center' },
  removeButton: { padding: 8, backgroundColor: '#e74c3c', borderRadius: 6 },
  removeButtonText: { color: 'white' },

  addButton: { marginTop: 12, padding: 12, backgroundColor: '#2ecc71', borderRadius: 8, alignItems: 'center' },
  addButtonText: { color: 'white', fontWeight: '700' },
  addMoodContainer: { marginTop: 12, backgroundColor: '#fff', padding: 12, borderRadius: 8 },
  addMoodLabel: { marginBottom: 8 },
  addMoodInput: { padding: 10, borderRadius: 8, backgroundColor: '#f7f7f7' },
  addMoodActions: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 8 },
  cancelAddButton: { padding: 10, backgroundColor: '#ecf0f1', borderRadius: 8 },
  cancelAddButtonText: { color: '#34495e' },
  confirmAddButton: { padding: 10, backgroundColor: '#3498db', borderRadius: 8 },
  confirmAddButtonText: { color: 'white' },
});
