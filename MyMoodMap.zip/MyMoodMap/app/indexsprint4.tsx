import * as Notifications from 'expo-notifications';
import React, { useEffect, useState } from 'react';
import { Alert, ScrollView, StyleSheet, Switch, Text, TextInput, TouchableOpacity, View } from 'react-native';

// Types
type Mood = '😊' | '😐' | '😢' | '😠' | '😴';
type MoodEntry = {
  id: string;
  mood: Mood;
  note: string;
  timestamp: Date;
  date: string;
};

type AppScreen = 'onboarding-1' | 'onboarding-2' | 'onboarding-3' | 'login' | 'welcome' | 'mood-entry' | 'history' | 'settings';

// Configure notifications
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: false,
    shouldShowBanner: true,
    shouldShowList: true,
  }),
});

export default function HomeScreen() {
  const [currentScreen, setCurrentScreen] = useState<AppScreen>('onboarding-1');
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [selectedMood, setSelectedMood] = useState<Mood | null>(null);
  const [note, setNote] = useState('');
  const [moodHistory, setMoodHistory] = useState<MoodEntry[]>([]);
  
  // USER STORY 7: Notification Settings
  const [notificationsEnabled, setNotificationsEnabled] = useState(false);
  const [reminderTime, setReminderTime] = useState('20:00'); // Default 8 PM

  // Check if user has completed onboarding
  useEffect(() => {
    checkOnboardingStatus();
    requestNotificationPermissions();
  }, []);

  const checkOnboardingStatus = async () => {
    // In real app, check AsyncStorage for onboarding completion
    // For demo, always show onboarding first
    setCurrentScreen('onboarding-1');
  };

  // USER STORY 7: Notification Permissions
  const requestNotificationPermissions = async () => {
    const { status } = await Notifications.requestPermissionsAsync();
    if (status !== 'granted') {
      Alert.alert('Notifications disabled', 'Enable notifications for daily reminders');
    }
  };

  // USER STORY 7: Schedule Daily Reminders
  const scheduleDailyReminder = async () => {
  if (!notificationsEnabled) return;

  try {
    const [hours, minutes] = reminderTime.split(':').map(Number);
    
    await Notifications.cancelAllScheduledNotificationsAsync();
    
    await Notifications.scheduleNotificationAsync({
      content: {
        title: 'Daily Mood Check-in',
        body: 'Take a moment to log how you\'re feeling today in My Mood Map.',
        sound: true,
        data: { type: 'daily-reminder' },
      },
      trigger: {
        type: 'daily', // REQUIRED: Specify the trigger type
        hour: hours,
        minute: minutes,
        repeats: true,
      },
    });

    console.log(`Scheduled daily reminder for ${hours}:${minutes}`);
  } catch (error) {
    console.error('Failed to schedule notification:', error);
    Alert.alert('Scheduling Error', 'Could not set up daily reminders.');
  }
};


  // USER STORY 7: Toggle Notifications
  const toggleNotifications = async (value: boolean) => {
  setNotificationsEnabled(value);
  
  if (value) {
    const { status } = await Notifications.requestPermissionsAsync();
    if (status === 'granted') {
      await scheduleDailyReminder();
      Alert.alert('Success', `Daily reminders enabled for ${reminderTime}`);
    } else {
      setNotificationsEnabled(false);
      Alert.alert('Permission Required', 'Please enable notifications in settings.');
    }
  } else {
    await Notifications.cancelAllScheduledNotificationsAsync();
    Alert.alert('Reminders Disabled', 'You will no longer receive daily reminders.');
  }
};

  // Simple storage
  let tempStorage: any = {};

  const tempAsyncStorage = {
    setItem: async (key: string, value: string) => {
      tempStorage[key] = value;
      return Promise.resolve();
    },
    getItem: async (key: string) => {
      return Promise.resolve(JSON.stringify(tempStorage[key]));
    },
  };

  const handleLogin = async () => {
    if (email && password) {
      try {
        await tempAsyncStorage.setItem('user', JSON.stringify({ email }));
        setIsLoggedIn(true);
        setCurrentScreen('welcome');
      } catch (error) {
        Alert.alert('Error', 'Failed to login');
      }
    } else {
      Alert.alert('Error', 'Please enter email and password');
    }
  };

  const saveMood = async () => {
    if (selectedMood) {
      const newEntry: MoodEntry = {
        id: Date.now().toString(),
        mood: selectedMood,
        note: note,
        timestamp: new Date(),
        date: new Date().toISOString().split('T')[0]
      };

      const updatedHistory = [newEntry, ...moodHistory];
      setMoodHistory(updatedHistory);
      Alert.alert('Mood Saved!', `You're feeling: ${selectedMood}`);
      setSelectedMood(null);
      setNote('');
    }
  };

  // ONBOARDING SCREENS
  const OnboardingScreen1 = () => (
    <View style={styles.onboardingContainer}>
      <Text style={styles.onboardingTitle}>Welcome to My Mood Map! 🌈</Text>
      <Text style={styles.onboardingDescription}>
        Track your daily emotions and understand your mood patterns over time.
      </Text>
      <View style={styles.onboardingImagePlaceholder}>
        <Text style={styles.emojiLarge}>📱</Text>
      </View>
      <TouchableOpacity 
        style={styles.onboardingButton}
        onPress={() => setCurrentScreen('onboarding-2')}
      >
        <Text style={styles.onboardingButtonText}>Next</Text>
      </TouchableOpacity>
      <TouchableOpacity 
        style={styles.skipButton}
        onPress={() => setCurrentScreen('login')}
      >
        <Text style={styles.skipButtonText}>Skip Tutorial</Text>
      </TouchableOpacity>
    </View>
  );

  const OnboardingScreen2 = () => (
    <View style={styles.onboardingContainer}>
      <Text style={styles.onboardingTitle}>Log Your Mood Daily ✨</Text>
      <Text style={styles.onboardingDescription}>
        Simply tap an emoji to log how you're feeling. Add optional notes for context.
      </Text>
      <View style={styles.onboardingImagePlaceholder}>
        <Text style={styles.emojiLarge}>😊 😐 😢 😠 😴</Text>
        <Text style={styles.onboardingSubtext}>Choose from 5 mood options</Text>
      </View>
      <TouchableOpacity 
        style={styles.onboardingButton}
        onPress={() => setCurrentScreen('onboarding-3')}
      >
        <Text style={styles.onboardingButtonText}>Next</Text>
      </TouchableOpacity>
    </View>
  );

  const OnboardingScreen3 = () => (
    <View style={styles.onboardingContainer}>
      <Text style={styles.onboardingTitle}>Track & Analyze 📊</Text>
      <Text style={styles.onboardingDescription}>
        View your mood history on a calendar and see trends with beautiful charts.
      </Text>
      <View style={styles.onboardingImagePlaceholder}>
        <Text style={styles.emojiLarge}>📅 📈</Text>
        <Text style={styles.onboardingSubtext}>Calendar and analytics views</Text>
      </View>
      <TouchableOpacity 
        style={styles.onboardingButton}
        onPress={() => setCurrentScreen('login')}
      >
        <Text style={styles.onboardingButtonText}>Get Started</Text>
      </TouchableOpacity>
    </View>
  );

  const LoginScreen = () => (
    <View style={styles.container}>
      <Text style={styles.title}>My Mood Map</Text>
      <Text style={styles.subtitle}>Welcome! Please login</Text>
      
      <View style={styles.inputContainer}>
        <TextInput
          style={styles.input}
          placeholder="Email"
          value={email}
          onChangeText={setEmail}
          keyboardType="email-address"
          autoCapitalize="none"
        />
        <TextInput
          style={styles.input}
          placeholder="Password"
          value={password}
          onChangeText={setPassword}
          secureTextEntry
        />
      </View>

      <TouchableOpacity style={styles.primaryButton} onPress={handleLogin}>
        <Text style={styles.buttonText}>Login</Text>
      </TouchableOpacity>

      <Text style={styles.demoText}>Use any email and password</Text>
    </View>
  );

  const WelcomeScreen = () => (
    <View style={styles.container}>
      <Text style={styles.title}>My Mood Map</Text>
      <Text style={styles.subtitle}>Welcome back! 👋</Text>
      
      <TouchableOpacity 
        style={styles.primaryButton}
        onPress={() => setCurrentScreen('mood-entry')}
      >
        <Text style={styles.buttonText}>Log Today's Mood</Text>
      </TouchableOpacity>

      <TouchableOpacity 
        style={styles.secondaryButton}
        onPress={() => setCurrentScreen('history')}
      >
        <Text style={styles.buttonText}>View History</Text>
      </TouchableOpacity>

      <TouchableOpacity 
        style={styles.tertiaryButton}
        onPress={() => setCurrentScreen('settings')}
      >
        <Text style={styles.buttonText}>Notification Settings</Text>
      </TouchableOpacity>

      <Text style={styles.stats}>
        You have {moodHistory.length} mood entries
      </Text>
    </View>
  );

  const MoodEntryScreen = () => {
    const moods: Mood[] = ['😊', '😐', '😢', '😠', '😴'];
    
    return (
      <ScrollView style={styles.container} contentContainerStyle={styles.scrollContent}>
        <Text style={styles.title}>How are you feeling?</Text>
        
        <View style={styles.moodContainer}>
          {moods.map((mood, index) => (
            <TouchableOpacity
              key={index}
              style={[
                styles.moodOption,
                selectedMood === mood && styles.selectedMood
              ]}
              onPress={() => setSelectedMood(mood)}
            >
              <Text style={styles.moodEmoji}>{mood}</Text>
            </TouchableOpacity>
          ))}
        </View>

        {selectedMood && (
          <View style={styles.noteContainer}>
            <Text style={styles.noteLabel}>Add a note (optional):</Text>
            <TextInput
              style={styles.textInput}
              placeholder="What's making you feel this way?"
              value={note}
              onChangeText={setNote}
              multiline
              maxLength={200}
            />
            <Text style={styles.charCount}>{note.length}/200 characters</Text>
          </View>
        )}

        <TouchableOpacity 
          style={[
            styles.saveButton,
            !selectedMood && styles.saveButtonDisabled
          ]}
          onPress={saveMood}
          disabled={!selectedMood}
        >
          <Text style={styles.saveButtonText}>
            {selectedMood ? 'Save Mood' : 'Select a Mood'}
          </Text>
        </TouchableOpacity>

        <TouchableOpacity 
          style={styles.backButton}
          onPress={() => setCurrentScreen('welcome')}
        >
          <Text style={styles.backButtonText}>Back to Home</Text>
        </TouchableOpacity>
      </ScrollView>
    );
  };

  const HistoryScreen = () => (
    <View style={styles.container}>
      <Text style={styles.title}>Mood History</Text>
      
      <ScrollView style={styles.historyContainer}>
        {moodHistory.length === 0 ? (
          <Text style={styles.noHistory}>No mood entries yet</Text>
        ) : (
          moodHistory.map((entry) => (
            <View key={entry.id} style={styles.historyItem}>
              <Text style={styles.historyEmoji}>{entry.mood}</Text>
              <View style={styles.historyDetails}>
                <Text style={styles.historyDate}>
                  {entry.timestamp.toLocaleDateString()} at {entry.timestamp.toLocaleTimeString()}
                </Text>
                {entry.note && (
                  <Text style={styles.historyNote}>"{entry.note}"</Text>
                )}
              </View>
            </View>
          ))
        )}
      </ScrollView>

      <TouchableOpacity 
        style={styles.backButton}
        onPress={() => setCurrentScreen('welcome')}
      >
        <Text style={styles.backButtonText}>Back to Home</Text>
      </TouchableOpacity>
    </View>
  );

  // USER STORY 7: Notification Settings Screen
  const SettingsScreen = () => (
    <View style={styles.container}>
      <Text style={styles.title}>Notification Settings</Text>
      
      <View style={styles.settingsContainer}>
        <View style={styles.settingItem}>
          <View style={styles.settingText}>
            <Text style={styles.settingTitle}>Daily Reminders</Text>
            <Text style={styles.settingDescription}>
              Receive daily notifications to log your mood
            </Text>
          </View>
          <Switch
            value={notificationsEnabled}
            onValueChange={toggleNotifications}
            trackColor={{ false: '#767577', true: '#81b0ff' }}
            thumbColor={notificationsEnabled ? '#3498db' : '#f4f3f4'}
          />
        </View>

        {notificationsEnabled && (
          <View style={styles.timeSetting}>
            <Text style={styles.timeLabel}>Reminder Time:</Text>
            <View style={styles.timeInputContainer}>
              <TextInput
                style={styles.timeInput}
                value={reminderTime}
                onChangeText={setReminderTime}
                placeholder="20:00"
                maxLength={5}
              />
              <Text style={styles.timeFormat}>24-hour format (HH:MM)</Text>
            </View>
            <TouchableOpacity 
              style={styles.testButton}
              onPress={async () => {
                await Notifications.scheduleNotificationAsync({
                  content: {
                    title: 'Test Reminder ✅',
                    body: 'This is a test of your daily mood reminder!',
                  },
                  trigger: null, // Show immediately
                });
                Alert.alert('Test Sent', 'Check for a notification!');
              }}
            >
              <Text style={styles.testButtonText}>Send Test Notification</Text>
            </TouchableOpacity>
          </View>
        )}
      </View>

      <TouchableOpacity 
        style={styles.backButton}
        onPress={() => setCurrentScreen('welcome')}
      >
        <Text style={styles.backButtonText}>Back to Home</Text>
      </TouchableOpacity>
    </View>
  );

  // Main navigation
  if (currentScreen.startsWith('onboarding')) {
    switch (currentScreen) {
      case 'onboarding-1': return <OnboardingScreen1 />;
      case 'onboarding-2': return <OnboardingScreen2 />;
      case 'onboarding-3': return <OnboardingScreen3 />;
    }
  }

  if (!isLoggedIn) {
    return <LoginScreen />;
  }

  return (
    <View style={styles.container}>
      {currentScreen === 'welcome' && <WelcomeScreen />}
      {currentScreen === 'mood-entry' && <MoodEntryScreen />}
      {currentScreen === 'history' && <HistoryScreen />}
      {currentScreen === 'settings' && <SettingsScreen />}
    </View>
  );
}

const styles = StyleSheet.create({
  // Onboarding Styles
  onboardingContainer: {
    flex: 1,
    backgroundColor: '#f8f9fa',
    padding: 40,
    justifyContent: 'center',
    alignItems: 'center',
  },
  onboardingTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#2c3e50',
    marginBottom: 20,
    textAlign: 'center',
  },
  onboardingDescription: {
    fontSize: 18,
    color: '#7f8c8d',
    textAlign: 'center',
    marginBottom: 40,
    lineHeight: 24,
  },
  onboardingSubtext: {
    fontSize: 14,
    color: '#95a5a6',
    textAlign: 'center',
    marginTop: 10,
  },
  onboardingImagePlaceholder: {
    backgroundColor: 'white',
    padding: 40,
    borderRadius: 20,
    marginBottom: 40,
    alignItems: 'center',
    elevation: 4,
  },
  emojiLarge: {
    fontSize: 48,
    marginBottom: 10,
  },
  onboardingButton: {
    backgroundColor: '#3498db',
    paddingVertical: 15,
    paddingHorizontal: 40,
    borderRadius: 30,
    marginBottom: 15,
  },
  onboardingButtonText: {
    color: 'white',
    fontSize: 18,
    fontWeight: '600',
  },
  skipButton: {
    paddingVertical: 10,
  },
  skipButtonText: {
    color: '#7f8c8d',
    fontSize: 16,
  },

  // Existing container styles
  container: {
    flex: 1,
    backgroundColor: '#f8f9fa',
    padding: 20,
  },
  scrollContent: {
    flexGrow: 1,
  },
  title: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#2c3e50',
    marginBottom: 10,
    textAlign: 'center',
  },
  subtitle: {
    fontSize: 18,
    color: '#7f8c8d',
    marginBottom: 30,
    textAlign: 'center',
  },
  demoText: {
    fontSize: 14,
    color: '#95a5a6',
    marginTop: 20,
    textAlign: 'center',
  },
  stats: {
    fontSize: 14,
    color: '#bdc3c7',
    textAlign: 'center',
    marginTop: 20,
  },

  // Input & Button Styles
  inputContainer: {
    width: '100%',
    maxWidth: 300,
    marginBottom: 30,
    alignSelf: 'center',
  },
  input: {
    backgroundColor: 'white',
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 10,
    padding: 15,
    marginBottom: 15,
    fontSize: 16,
  },
  primaryButton: {
    backgroundColor: '#3498db',
    paddingVertical: 15,
    paddingHorizontal: 40,
    borderRadius: 30,
    marginVertical: 8,
    minWidth: 200,
    alignItems: 'center',
    alignSelf: 'center',
  },
  secondaryButton: {
    backgroundColor: '#9b59b6',
    paddingVertical: 15,
    paddingHorizontal: 40,
    borderRadius: 30,
    marginVertical: 8,
    minWidth: 200,
    alignItems: 'center',
    alignSelf: 'center',
  },
  tertiaryButton: {
    backgroundColor: '#1abc9c',
    paddingVertical: 15,
    paddingHorizontal: 40,
    borderRadius: 30,
    marginVertical: 8,
    minWidth: 200,
    alignItems: 'center',
    alignSelf: 'center',
  },
  saveButton: {
    backgroundColor: '#27ae60',
    paddingVertical: 16,
    borderRadius: 30,
    alignItems: 'center',
    marginBottom: 15,
    width: '100%',
  },
  saveButtonDisabled: {
    backgroundColor: '#bdc3c7',
  },
  backButton: {
    paddingVertical: 12,
    alignItems: 'center',
  },
  buttonText: {
    color: 'white',
    fontSize: 18,
    fontWeight: '600',
  },
  saveButtonText: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
  },
  backButtonText: {
    color: '#7f8c8d',
    fontSize: 16,
  },

  // Mood Selection
  moodContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
    marginBottom: 30,
  },
  moodOption: {
    alignItems: 'center',
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 20,
    margin: 8,
    elevation: 3,
    borderWidth: 3,
    borderColor: 'transparent',
  },
  selectedMood: {
    borderColor: '#3498db',
    backgroundColor: '#e3f2fd',
  },
  moodEmoji: {
    fontSize: 36,
  },

  // Note Input
  noteContainer: {
    width: '100%',
    marginBottom: 30,
  },
  noteLabel: {
    fontSize: 18,
    fontWeight: '600',
    color: '#2c3e50',
    marginBottom: 12,
    textAlign: 'center',
  },
  textInput: {
    backgroundColor: 'white',
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 15,
    padding: 15,
    minHeight: 120,
    fontSize: 16,
    textAlignVertical: 'top',
  },
  charCount: {
    textAlign: 'right',
    color: '#95a5a6',
    fontSize: 12,
    marginTop: 5,
  },

  // History
  historyContainer: {
    flex: 1,
    marginBottom: 20,
  },
  historyItem: {
    backgroundColor: 'white',
    padding: 15,
    borderRadius: 15,
    marginBottom: 10,
    flexDirection: 'row',
    alignItems: 'center',
    elevation: 2,
  },
  historyEmoji: {
    fontSize: 30,
    marginRight: 15,
  },
  historyDetails: {
    flex: 1,
  },
  historyDate: {
    fontSize: 14,
    color: '#7f8c8d',
    marginBottom: 4,
  },
  historyNote: {
    fontSize: 16,
    color: '#2c3e50',
    fontStyle: 'italic',
  },
  noHistory: {
    textAlign: 'center',
    color: '#95a5a6',
    fontSize: 16,
    marginTop: 50,
  },

  // Settings
  settingsContainer: {
    backgroundColor: 'white',
    borderRadius: 15,
    padding: 20,
    marginBottom: 20,
    elevation: 2,
  },
  settingItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  settingText: {
    flex: 1,
    marginRight: 15,
  },
  settingTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#2c3e50',
    marginBottom: 4,
  },
  settingDescription: {
    fontSize: 14,
    color: '#7f8c8d',
  },
  timeSetting: {
    borderTopWidth: 1,
    borderTopColor: '#ecf0f1',
    paddingTop: 20,
  },
  timeLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: '#2c3e50',
    marginBottom: 10,
  },
  timeInputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 15,
  },
  timeInput: {
    backgroundColor: '#f8f9fa',
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 8,
    padding: 10,
    fontSize: 16,
    width: 80,
    marginRight: 10,
    textAlign: 'center',
  },
  timeFormat: {
    fontSize: 12,
    color: '#95a5a6',
  },
  testButton: {
    backgroundColor: '#f39c12',
    paddingVertical: 10,
    paddingHorizontal: 15,
    borderRadius: 20,
    alignSelf: 'flex-start',
  },
  testButtonText: {
    color: 'white',
    fontSize: 14,
    fontWeight: '600',
  },
});